def ternary_search(arr, x):
    pass
