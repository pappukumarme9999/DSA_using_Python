def depth_first_search(arr, x):
    pass