def breadth_first_search(arr, x):
    
    pass